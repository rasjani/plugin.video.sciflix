xbmc-sciflix
============

This is a video addon for KODI platform, showing content from
http://sciflix.blogspot.com website.

If you have good suggestions to what videos should be added to the list (currently about 130), drop me a note at jani dot mikkonen at the usual gmail dot com.






